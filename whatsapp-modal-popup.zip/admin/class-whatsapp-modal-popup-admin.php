<?php

/**
 * Gerencia a área de administração do plugin.
 */
class WhatsApp_Modal_Popup_Admin {

    private $plugin_name;
    private $version;

    public function __construct( $plugin_name, $version ) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
    }

    public function enqueue_styles() {
        if ( isset( $_GET['page'] ) && $_GET['page'] === $this->plugin_name ) {
            wp_enqueue_style( $this->plugin_name, WMP_PLUGIN_URL . 'admin/css/whatsapp-modal-popup-admin.css', array(), $this->version, 'all' );
            wp_enqueue_style( 'wp-color-picker' );
            wp_enqueue_style( 'thickbox' );
        }
    }

    public function enqueue_scripts() {
        if ( isset( $_GET['page'] ) && $_GET['page'] === $this->plugin_name ) {
            wp_enqueue_script(
                $this->plugin_name,
                WMP_PLUGIN_URL . 'admin/js/whatsapp-modal-popup-admin.js',
                array( 'jquery', 'wp-color-picker', 'media-upload', 'thickbox' ),
                $this->version,
                true
            );
        }
    }

    public function add_plugin_admin_menu() {
        add_options_page(
            'WhatsApp Modal Popup Settings',
            'WhatsApp Modal Popup',
            'manage_options',
            $this->plugin_name,
            array( $this, 'display_plugin_setup_page' )
        );
    }

    public function display_plugin_setup_page() {
        // Garante que a biblioteca de mídia do WordPress seja carregada ANTES do HTML da página
        wp_enqueue_media();
        include_once WMP_PLUGIN_DIR . 'admin/partials/whatsapp-modal-popup-admin-display.php';
    }

    public function setup_sections() {
        add_settings_section(
            'wmp_general_settings_section',
            'Configurações Gerais',
            array( $this, 'wmp_general_settings_section_callback' ),
            $this->plugin_name
        );
        add_settings_section(
            'wmp_style_settings_section',
            'Personalização de Estilo',
            array( $this, 'wmp_style_settings_section_callback' ),
            $this->plugin_name
        );
    }

    public function wmp_general_settings_section_callback() {
        echo '<p>Configure as opções do seu modal popup do WhatsApp.</p>';
    }

    public function wmp_style_settings_section_callback() {
        echo '<p>Personalize as cores do seu modal.</p>';
    }

    public function setup_fields() {
        // Configurações Gerais
        add_settings_field(
            'wmp_custom_logo',
            'Logo Personalizado',
            array( $this, 'wmp_custom_logo_callback' ),
            $this->plugin_name,
            'wmp_general_settings_section'
        );

        add_settings_field(
            'wmp_channel_link',
            'Link do Canal do WhatsApp',
            array( $this, 'wmp_channel_link_callback' ),
            $this->plugin_name,
            'wmp_general_settings_section'
        );

        add_settings_field(
            'wmp_modal_title',
            'Título do Modal',
            array( $this, 'wmp_modal_title_callback' ),
            $this->plugin_name,
            'wmp_general_settings_section'
        );

        add_settings_field(
            'wmp_modal_message',
            'Mensagem do Modal',
            array( $this, 'wmp_modal_message_callback' ),
            $this->plugin_name,
            'wmp_general_settings_section'
        );

        add_settings_field(
            'wmp_display_trigger',
            'Gatilho de Exibição',
            array( $this, 'wmp_display_trigger_callback' ),
            $this->plugin_name,
            'wmp_general_settings_section'
        );

        add_settings_field(
            'wmp_display_delay',
            'Atraso de Exibição (segundos)',
            array( $this, 'wmp_display_delay_callback' ),
            $this->plugin_name,
            'wmp_general_settings_section'
        );

        // Configurações de Estilo
        add_settings_field(
            'wmp_bg_color',
            'Cor de Fundo do Modal',
            array( $this, 'wmp_bg_color_callback' ),
            $this->plugin_name,
            'wmp_style_settings_section'
        );

        add_settings_field(
            'wmp_text_color',
            'Cor do Texto',
            array( $this, 'wmp_text_color_callback' ),
            $this->plugin_name,
            'wmp_style_settings_section'
        );

        add_settings_field(
            'wmp_btn_bg_color',
            'Cor do Botão',
            array( $this, 'wmp_btn_bg_color_callback' ),
            $this->plugin_name,
            'wmp_style_settings_section'
        );

        add_settings_field(
            'wmp_btn_text_color',
            'Cor do Texto do Botão',
            array( $this, 'wmp_btn_text_color_callback' ),
            $this->plugin_name,
            'wmp_style_settings_section'
        );

        register_setting( $this->plugin_name, 'whatsapp_modal_popup_options', array( $this, 'sanitize_options' ) );
    }

    public function wmp_custom_logo_callback() {
        $options = get_option( 'whatsapp_modal_popup_options' );
        $logo_url = isset( $options['custom_logo'] ) ? esc_url( $options['custom_logo'] ) : '';
        ?>
        <div class="wmp-logo-preview-wrapper">
            <img id="wmp-logo-preview" src="<?php echo esc_attr( $logo_url ); ?>" style="max-width: 150px; display: <?php echo $logo_url ? 'block' : 'none'; ?>; margin-bottom: 10px;" />
            <input type="hidden" name="whatsapp_modal_popup_options[custom_logo]" id="wmp-custom-logo-url" value="<?php echo esc_attr( $logo_url ); ?>" />
            <button type="button" class="button" id="wmp-upload-logo-btn">Selecionar Logo</button>
            <button type="button" class="button" id="wmp-remove-logo-btn" style="display: <?php echo $logo_url ? 'inline-block' : 'none'; ?>;">Remover</button>
        </div>
        <p class="description">Faça upload de uma imagem para substituir o ícone padrão do WhatsApp no topo do modal.</p>
        <?php
    }

    public function wmp_channel_link_callback() {
        $options = get_option( 'whatsapp_modal_popup_options' );
        $link = isset( $options['channel_link'] ) ? esc_url( $options['channel_link'] ) : '';
        echo '<input type="url" name="whatsapp_modal_popup_options[channel_link]" value="' . esc_attr( $link ) . '" class="regular-text" />';
        echo '<p class="description">Insira o link completo do seu canal do WhatsApp.</p>';
    }

    public function wmp_modal_title_callback() {
        $options = get_option( 'whatsapp_modal_popup_options' );
        $title = isset( $options['modal_title'] ) ? sanitize_text_field( $options['modal_title'] ) : 'Junte-se ao nosso canal no WhatsApp!';
        echo '<input type="text" name="whatsapp_modal_popup_options[modal_title]" value="' . esc_attr( $title ) . '" class="regular-text" />';
    }

    public function wmp_modal_message_callback() {
        $options = get_option( 'whatsapp_modal_popup_options' );
        $message = isset( $options['modal_message'] ) ? sanitize_textarea_field( $options['modal_message'] ) : 'Receba as últimas notícias e promoções diretamente no seu celular.';
        echo '<textarea name="whatsapp_modal_popup_options[modal_message]" rows="5" cols="50" class="large-text">' . esc_textarea( $message ) . '</textarea>';
    }

    public function wmp_display_trigger_callback() {
        $options = get_option( 'whatsapp_modal_popup_options' );
        $trigger = isset( $options['display_trigger'] ) ? sanitize_text_field( $options['display_trigger'] ) : 'time_delay';
        ?>
        <select name="whatsapp_modal_popup_options[display_trigger]">
            <option value="time_delay" <?php selected( $trigger, 'time_delay' ); ?>>Atraso de Tempo</option>
            <option value="scroll_percentage" <?php selected( $trigger, 'scroll_percentage' ); ?>>Porcentagem de Rolagem</option>
            <option value="exit_intent" <?php selected( $trigger, 'exit_intent' ); ?>>Intenção de Saída</option>
        </select>
        <?php
    }

    public function wmp_display_delay_callback() {
        $options = get_option( 'whatsapp_modal_popup_options' );
        $delay = isset( $options['display_delay'] ) ? absint( $options['display_delay'] ) : 5;
        echo '<input type="number" name="whatsapp_modal_popup_options[display_delay]" value="' . esc_attr( $delay ) . '" min="1" />';
    }

    public function wmp_bg_color_callback() {
        $options = get_option( 'whatsapp_modal_popup_options' );
        $color = isset( $options['bg_color'] ) ? $options['bg_color'] : '#ffffff';
        echo '<input type="text" name="whatsapp_modal_popup_options[bg_color]" value="' . esc_attr( $color ) . '" class="wmp-color-picker" />';
    }

    public function wmp_text_color_callback() {
        $options = get_option( 'whatsapp_modal_popup_options' );
        $color = isset( $options['text_color'] ) ? $options['text_color'] : '#333333';
        echo '<input type="text" name="whatsapp_modal_popup_options[text_color]" value="' . esc_attr( $color ) . '" class="wmp-color-picker" />';
    }

    public function wmp_btn_bg_color_callback() {
        $options = get_option( 'whatsapp_modal_popup_options' );
        $color = isset( $options['btn_bg_color'] ) ? $options['btn_bg_color'] : '#25d366';
        echo '<input type="text" name="whatsapp_modal_popup_options[btn_bg_color]" value="' . esc_attr( $color ) . '" class="wmp-color-picker" />';
    }

    public function wmp_btn_text_color_callback() {
        $options = get_option( 'whatsapp_modal_popup_options' );
        $color = isset( $options['btn_text_color'] ) ? $options['btn_text_color'] : '#ffffff';
        echo '<input type="text" name="whatsapp_modal_popup_options[btn_text_color]" value="' . esc_attr( $color ) . '" class="wmp-color-picker" />';
    }

    public function sanitize_options( $input ) {
        $new_input = array();
        if ( isset( $input['custom_logo'] ) ) {
            $new_input['custom_logo'] = esc_url_raw( $input['custom_logo'] );
        }
        if ( isset( $input['channel_link'] ) ) {
            $new_input['channel_link'] = esc_url_raw( $input['channel_link'] );
        }
        if ( isset( $input['modal_title'] ) ) {
            $new_input['modal_title'] = sanitize_text_field( $input['modal_title'] );
        }
        if ( isset( $input['modal_message'] ) ) {
            $new_input['modal_message'] = sanitize_textarea_field( $input['modal_message'] );
        }
        if ( isset( $input['display_trigger'] ) ) {
            $new_input['display_trigger'] = sanitize_text_field( $input['display_trigger'] );
        }
        if ( isset( $input['display_delay'] ) ) {
            $new_input['display_delay'] = absint( $input['display_delay'] );
        }
        if ( isset( $input['bg_color'] ) ) {
            $new_input['bg_color'] = sanitize_hex_color( $input['bg_color'] );
        }
        if ( isset( $input['text_color'] ) ) {
            $new_input['text_color'] = sanitize_hex_color( $input['text_color'] );
        }
        if ( isset( $input['btn_bg_color'] ) ) {
            $new_input['btn_bg_color'] = sanitize_hex_color( $input['btn_bg_color'] );
        }
        if ( isset( $input['btn_text_color'] ) ) {
            $new_input['btn_text_color'] = sanitize_hex_color( $input['btn_text_color'] );
        }
        return $new_input;
    }

    public function handle_option_update( $old_value, $new_value ) {}

}
