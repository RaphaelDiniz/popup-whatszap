jQuery(document).ready(function($) {
    'use strict';

    // Inicializa o seletor de cores
    if ($.isFunction($.fn.wpColorPicker)) {
        $('.wmp-color-picker').wpColorPicker();
    }

    // Gerenciador de Upload de Logo
    var mediaUploader;

    $('#wmp-upload-logo-btn').on('click', function(e) {
        e.preventDefault();

        // Verificação de segurança: garante que a biblioteca wp.media foi carregada
        if (typeof wp === 'undefined' || typeof wp.media === 'undefined') {
            alert('Erro: a biblioteca de mídia do WordPress não foi carregada. Recarregue a página e tente novamente.');
            return;
        }

        // Se o objeto mediaUploader já existir, abra-o.
        if (mediaUploader) {
            mediaUploader.open();
            return;
        }

        // Cria o objeto mediaUploader.
        mediaUploader = wp.media({
            title: 'Selecionar Logo',
            button: {
                text: 'Usar este Logo'
            },
            multiple: false
        });

        // Quando uma imagem é selecionada, execute um callback.
        mediaUploader.on('select', function() {
            var attachment = mediaUploader.state().get('selection').first().toJSON();
            $('#wmp-logo-preview').attr('src', attachment.url).show();
            $('#wmp-custom-logo-url').val(attachment.url);
            $('#wmp-remove-logo-btn').show();
        });

        // Abre o uploader.
        mediaUploader.open();
    });

    // Remover Logo
    $('#wmp-remove-logo-btn').on('click', function(e) {
        e.preventDefault();
        if (confirm('Tem certeza que deseja remover o logo?')) {
            $('#wmp-logo-preview').attr('src', '').hide();
            $('#wmp-custom-logo-url').val('');
            $(this).hide();
        }
    });
});
