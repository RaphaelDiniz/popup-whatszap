<?php
/**
 * Template para a página de configurações do plugin no admin.
 */
?>
<div class="wrap">
    <h1>WhatsApp Modal Popup Settings</h1>
    <form method="post" action="options.php">
        <?php
        settings_fields( 'whatsapp-modal-popup' );
        do_settings_sections( 'whatsapp-modal-popup' );
        submit_button();
        ?>
    </form>
</div>
