(function($) {
    'use strict';

    $(document).ready(function() {
        var modal = $('#wmp-modal-overlay');
        var closeBtn = $('.wmp-modal-close');
        var trigger = wmp_vars.display_trigger;
        var delay = parseInt(wmp_vars.display_delay) * 1000;
        var modalShown = localStorage.getItem('wmp_modal_shown');

        if (modalShown) {
            return; // Não exibe se o usuário já fechou o modal nesta sessão.
        }

        function showModal() {
            modal.addClass('active');
        }

        function closeModal() {
            modal.removeClass('active');
            localStorage.setItem('wmp_modal_shown', 'true');
        }

        closeBtn.on('click', closeModal);

        $(window).on('click', function(event) {
            if ($(event.target).is(modal)) {
                closeModal();
            }
        });

        // Lógica dos gatilhos
        if (trigger === 'time_delay') {
            setTimeout(showModal, delay);
        } else if (trigger === 'scroll_percentage') {
            $(window).on('scroll', function() {
                var scrollPercent = ($(window).scrollTop() / ($(document).height() - $(window).height())) * 100;
                if (scrollPercent > 50) { // Exibe após 50% de rolagem
                    showModal();
                    $(window).off('scroll');
                }
            });
        } else if (trigger === 'exit_intent') {
            $(document).on('mouseleave', function(e) {
                if (e.clientY < 0) {
                    showModal();
                    $(document).off('mouseleave');
                }
            });
        }
    });

})(jQuery);
