<?php

/**
 * Gerencia a área pública do plugin.
 */
class WhatsApp_Modal_Popup_Public {

    private $plugin_name;
    private $version;

    public function __construct( $plugin_name, $version ) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
    }

    public function enqueue_styles() {
        wp_enqueue_style( $this->plugin_name, WMP_PLUGIN_URL . 'public/css/whatsapp-modal-popup-public.css', array(), $this->version, 'all' );
        
        // Adiciona CSS dinâmico para as cores personalizadas
        $options = get_option( 'whatsapp_modal_popup_options' );
        $bg_color = isset( $options['bg_color'] ) ? $options['bg_color'] : '#ffffff';
        $text_color = isset( $options['text_color'] ) ? $options['text_color'] : '#333333';
        $btn_bg_color = isset( $options['btn_bg_color'] ) ? $options['btn_bg_color'] : '#25d366';
        $btn_text_color = isset( $options['btn_text_color'] ) ? $options['btn_text_color'] : '#ffffff';

        $custom_css = "
            .wmp-modal-container { background-color: {$bg_color} !important; }
            .wmp-modal-title, .wmp-modal-message { color: {$text_color} !important; }
            .wmp-modal-button { background-color: {$btn_bg_color} !important; color: {$btn_text_color} !important; }
            .wmp-modal-button:hover { filter: brightness(90%); }
        ";
        wp_add_inline_style( $this->plugin_name, $custom_css );
    }

    public function enqueue_scripts() {
        // true = carrega no rodapé, garantindo que jQuery e wmp_vars estejam disponíveis
        wp_enqueue_script( $this->plugin_name, WMP_PLUGIN_URL . 'public/js/whatsapp-modal-popup-public.js', array( 'jquery' ), $this->version, true );

        $options = get_option( 'whatsapp_modal_popup_options' );
        $display_trigger = isset( $options['display_trigger'] ) ? sanitize_text_field( $options['display_trigger'] ) : 'time_delay';
        $display_delay = isset( $options['display_delay'] ) ? absint( $options['display_delay'] ) : 5;

        wp_localize_script(
            $this->plugin_name,
            'wmp_vars',
            array(
                'display_trigger' => $display_trigger,
                'display_delay'   => $display_delay,
            )
        );
    }

    public function display_whatsapp_modal() {
        $options = get_option( 'whatsapp_modal_popup_options' );
        $modal_title = isset( $options['modal_title'] ) ? sanitize_text_field( $options['modal_title'] ) : 'Junte-se ao nosso canal no WhatsApp!';
        $modal_message = isset( $options['modal_message'] ) ? sanitize_textarea_field( $options['modal_message'] ) : 'Receba as últimas notícias e promoções diretamente no seu celular.';
        $channel_link = isset( $options['channel_link'] ) ? esc_url( $options['channel_link'] ) : '';
        $custom_logo = isset( $options['custom_logo'] ) ? esc_url( $options['custom_logo'] ) : '';

        if ( empty( $channel_link ) ) {
            return;
        }

        include_once WMP_PLUGIN_DIR . 'public/partials/whatsapp-modal-popup-display.php';
    }

}
