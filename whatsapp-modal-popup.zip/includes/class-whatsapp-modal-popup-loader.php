<?php

/**
 * Registra todas as ações e filtros para o plugin.
 */
class WhatsApp_Modal_Popup_Loader {

    /**
     * As ações registradas com o WordPress.
     * @var    array    Um registro de cada ação que foi registrada com o WordPress.
     * @access   protected
     */
    protected $actions;

    /**
     * Os filtros registrados com o WordPress.
     * @var    array    Um registro de cada filtro que foi registrado com o WordPress.
     * @access   protected
     */
    protected $filters;

    /**
     * Inicializa as coleções usadas para manter as ações e filtros.
     */
    public function __construct() {
        $this->actions = array();
        $this->filters = array();
    }

    /**
     * Adiciona uma nova ação ao array de ações a serem registradas com o WordPress.
     * @param    string    $hook             O nome do hook do WordPress que estamos direcionando.
     * @param    object    $component        Uma referência à instância da classe no qual o método é definido.
     * @param    string    $callback         O nome do método dentro da instância da classe.
     * @param    int       $priority         Opcional. A prioridade na qual a função deve ser executada. Padrão para 10.
     * @param    int       $accepted_args    Opcional. O número de argumentos que a função deve aceitar. Padrão para 1.
     */
    public function add_action( $hook, $component, $callback, $priority = 10, $accepted_args = 1 ) {
        $this->actions = $this->add( $this->actions, $hook, $component, $callback, $priority, $accepted_args );
    }

    /**
     * Adiciona um novo filtro ao array de filtros a serem registrados com o WordPress.
     * @param    string    $hook             O nome do hook do WordPress que estamos direcionando.
     * @param    object    $component        Uma referência à instância da classe no qual o método é definido.
     * @param    string    $callback         O nome do método dentro da instância da classe.
     * @param    int       $priority         Opcional. A prioridade na qual a função deve ser executada. Padrão para 10.
     * @param    int       $accepted_args    Opcional. O número de argumentos que a função deve aceitar. Padrão para 1.
     */
    public function add_filter( $hook, $component, $callback, $priority = 10, $accepted_args = 1 ) {
        $this->filters = $this->add( $this->filters, $hook, $component, $callback, $priority, $accepted_args );
    }

    /**
     * Uma função de utilidade para registrar uma única ação ou filtro para o WordPress.
     * @access   private
     * @param    array     $hooks            A referência para o array de hooks a serem atualizados.
     * @param    string    $hook             O nome do hook do WordPress que estamos direcionando.
     * @param    object    $component        Uma referência à instância da classe no qual o método é definido.
     * @param    string    $callback         O nome do método dentro da instância da classe.
     * @param    int       $priority         A prioridade na qual a função deve ser executada.
     * @param    int       $accepted_args    O número de argumentos que a função deve aceitar.
     * @return   array     O array de hooks atualizado.
     */
    private function add( $hooks, $hook, $component, $callback, $priority, $accepted_args ) {
        $hooks[] = array(
            'hook'          => $hook,
            'component'     => $component,
            'callback'      => $callback,
            'priority'      => $priority,
            'accepted_args' => $accepted_args
        );
        return $hooks;
    }

    /**
     * Registra os filtros e ações com o WordPress para que eles possam ser executados.
     */
    public function run() {
        foreach ( $this->filters as $hook ) {
            add_filter( $hook['hook'], array( $hook['component'], $hook['callback'] ), $hook['priority'], $hook['accepted_args'] );
        }
        foreach ( $this->actions as $hook ) {
            add_action( $hook['hook'], array( $hook['component'], $hook['callback'] ), $hook['priority'], $hook['accepted_args'] );
        }
    }

}
