<?php

/**
 * Classe principal do plugin WhatsApp Modal Popup.
 */
class WhatsApp_Modal_Popup {

    /**
     * O carregador que gerencia os hooks e filtros do plugin.
     * @var    WhatsApp_Modal_Popup_Loader    Gerencia os hooks do plugin.
     * @access   protected
     */
    protected $loader;

    /**
     * O identificador único deste plugin.
     * @var    string    O identificador único deste plugin.
     * @access   protected
     */
    protected $plugin_name;

    /**
     * A versão atual do plugin.
     * @var    string    A versão atual do plugin.
     * @access   protected
     */
    protected $version;

    /**
     * Define a funcionalidade principal do plugin.
     */
    public function __construct() {
        $this->plugin_name = 'whatsapp-modal-popup';
        $this->version = WMP_VERSION;

        $this->load_dependencies();
        $this->define_admin_hooks();
        $this->define_public_hooks();
    }

    /**
     * Carrega as dependências necessárias para este plugin.
     * @access   private
     */
    private function load_dependencies() {
        require_once WMP_PLUGIN_DIR . 'includes/class-whatsapp-modal-popup-loader.php';
        require_once WMP_PLUGIN_DIR . 'admin/class-whatsapp-modal-popup-admin.php';
        require_once WMP_PLUGIN_DIR . 'public/class-whatsapp-modal-popup-public.php';

        $this->loader = new WhatsApp_Modal_Popup_Loader();
    }

    /**
     * Registra todos os hooks relacionados à área de administração do plugin.
     * @access   private
     */
    private function define_admin_hooks() {
        $plugin_admin = new WhatsApp_Modal_Popup_Admin( $this->get_plugin_name(), $this->get_version() );

        $this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
        $this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );
        $this->loader->add_action( 'admin_menu', $plugin_admin, 'add_plugin_admin_menu' );
        $this->loader->add_action( 'admin_init', $plugin_admin, 'setup_sections' );
        $this->loader->add_action( 'admin_init', $plugin_admin, 'setup_fields' );
        $this->loader->add_action( 'update_option_whatsapp_modal_popup_options', $plugin_admin, 'handle_option_update', 10, 2 );
    }

    /**
     * Registra todos os hooks relacionados à área pública do plugin.
     * @access   private
     */
    private function define_public_hooks() {
        $plugin_public = new WhatsApp_Modal_Popup_Public( $this->get_plugin_name(), $this->get_version() );

        $this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
        $this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );
        $this->loader->add_action( 'wp_footer', $plugin_public, 'display_whatsapp_modal' );
    }

    /**
     * Executa o carregador para executar todos os hooks registrados.
     */
    public function run() {
        $this->loader->run();
    }

    /**
     * Retorna o nome do plugin.
     * @return    string    O nome do plugin.
     */
    public function get_plugin_name() {
        return $this->plugin_name;
    }

    /**
     * Retorna a versão do plugin.
     * @return    string    A versão do plugin.
     */
    public function get_version() {
        return $this->version;
    }

    /**
     * Retorna o carregador do plugin.
     * @return    WhatsApp_Modal_Popup_Loader    O carregador de hooks do plugin.
     */
    public function get_loader() {
        return $this->loader;
    }

}
